package com.softtek.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.BodyExtractors;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.softtek.models.Alumno;
import com.softtek.services.IAlumnosService;

import reactor.core.publisher.Mono;

@Component
public class HandlerAlumnos {
	
	@Autowired
	private IAlumnosService service;
	
	public Mono<ServerResponse> todos(ServerRequest request){
		return ServerResponse.ok()
				.contentType(MediaType.APPLICATION_JSON)
				.body(service.consultarTodos(), Alumno.class);
	}
	
	public Mono<ServerResponse> buscarId(ServerRequest request){
		// Comprobar si existe el alumno con ese id o no
		return service.buscarPorId(request.pathVariable("id"))
				.flatMap(alum -> ServerResponse.ok()
						.contentType(MediaType.APPLICATION_JSON)
						.body(Mono.just(alum), Alumno.class))
				.switchIfEmpty(ServerResponse.notFound()
				.build());
	}
	
	public Mono<ServerResponse> buscarNombre(ServerRequest request){
		// Comprobar si existe el alumno con ese nombre o no
		return service.buscarPorNombre(request.pathVariable("nombre"))
				.flatMap(alum -> ServerResponse.ok()
						.contentType(MediaType.APPLICATION_JSON)
						.body(Mono.just(alum), Alumno.class))
				.switchIfEmpty(ServerResponse.notFound()
				.build());
	}
	
	public Mono<ServerResponse> crearAlumnoREST(ServerRequest request){
		
		// Solucion  si recibo los datos del alumno en la url	
		return ServerResponse.ok()
				.contentType(MediaType.APPLICATION_JSON)
				.body(service.insertar(new Alumno(request.pathVariable("nombre"), 
						request.pathVariable("apellido"), Double.parseDouble(request.pathVariable("nota")))), Alumno.class);
	}
	
	public Mono<ServerResponse> crearAlumno(ServerRequest request){
		
		// Solucion si recibo el alumno en el body
		return request.bodyToMono(Alumno.class) 
				.flatMap(body -> ServerResponse.ok() 
				.contentType(MediaType.APPLICATION_JSON) 
				.body(service.insertar(body), Alumno.class));
	}
	
	
	public Mono<ServerResponse> modificar(ServerRequest request){
		return request.bodyToMono(Alumno.class) 
				.flatMap(body -> ServerResponse.ok() 
				.contentType(MediaType.APPLICATION_JSON) 
				.body(service.modificar(body), Alumno.class));
	}
	
	
	public Mono<ServerResponse> eliminar(ServerRequest request){
		
		// Solucion 1
//		return service.buscarPorId(request.pathVariable("id"))
//				.flatMap(alum -> service.eliminar(alum.getId()).then(ServerResponse.ok().build()))
//				.switchIfEmpty(ServerResponse.notFound().build());
		
		// Solucion 2
		return service.eliminar(request.pathVariable("id")) 
				.then(ServerResponse.noContent().build());
	}

}









