package com.softtek;

import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;


import com.softtek.models.Alumno;

@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
class Ejemplo2SpringWebFluxApplicationTests {
	
	@Autowired
	private WebTestClient client;

	@Test
	public void todosTest() {
		client.get()
			.uri("/handler/alumnos")
			.accept(MediaType.APPLICATION_JSON)
			.exchange()
			.expectStatus().isOk()
			.expectBodyList(Alumno.class)
			.consumeWith(response -> {
				List<Alumno> alumnos = response.getResponseBody();
				alumnos.forEach(alum -> {
					System.out.println(alum.getNombre());
				});
				Assertions.assertThat(alumnos.size()==4).isTrue();
			});
			//.hasSize(8);
	}

}
