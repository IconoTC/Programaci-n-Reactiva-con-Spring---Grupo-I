package com.softtek;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.web.reactive.function.server.RequestPredicates;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.softtek.models.Alumno;
import com.softtek.rest.HandlerAlumnos;

import reactor.core.publisher.Flux;

@SpringBootApplication
public class Ejemplo2SpringWebFluxApplication implements CommandLineRunner{
	
	@Autowired
	private ReactiveMongoTemplate mongoTemplate;
	
	@Bean
	public RouterFunction<ServerResponse> rutas(HandlerAlumnos handler){
		return RouterFunctions
				// http://localhost:8081/handler/alumnos
				.route(RequestPredicates.GET("/handler/alumnos"), handler::todos)
				// http://localhost:8081/handler/alumnos/.......
				.andRoute(RequestPredicates.GET("/handler/alumnos/{id}"), handler::buscarId)
				// http://localhost:8081/handler/alumnos/nombre/.......
				.andRoute(RequestPredicates.GET("/handler/alumnos/nombre/{nombre}"), handler::buscarNombre)
				// http://localhost:8081/handler/alumnos/nombre/Nuevo/apellido/Prueba/nota/3.5
				.andRoute(RequestPredicates.POST("/handler/alumnos/nombre/{nombre}/apellido/{apellido}/nota/{nota}"), handler::crearAlumnoREST)
				// http://localhost:8081/handler/alumnos
				.andRoute(RequestPredicates.POST("/handler/alumnos"), handler::crearAlumno)
				// http://localhost:8081/handler/alumnos/.......
				.andRoute(RequestPredicates.DELETE("/handler/alumnos/{id}"), handler::eliminar)
				// "/handler/alumnos"
				.andRoute(RequestPredicates.PUT("/handler/alumnos"), handler::modificar);
	}
	
	

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo2SpringWebFluxApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// Borrar los datos anteriores
		mongoTemplate.dropCollection("alumnos").subscribe();
		
		// carga inicial de datos
		// Crear un flujo de alumnos y persistirlos
		
		// Crear una lista de alumnos
		List<Alumno> lista = new LinkedList<>(Arrays.asList(
				new Alumno("Juan", "Lopez", 6.8),
				new Alumno("Maria", "Arias", 4.6),
				new Alumno("Antonio", "Rodriguez", 9.2),
				new Alumno("Laura", "Sanchez", 7.3)));
		
		Flux.fromIterable(lista)
			.flatMap(alum -> mongoTemplate.save(alum))
			.doOnComplete(() -> System.out.println("--- FIN ---"))
			.subscribe(alum -> System.out.println(alum));
					
	}

}
