package com.softtek.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.softtek.models.Alumno;
import com.softtek.persistence.AlumnosDAO;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class AlumnosServiceImpl implements IAlumnosService{
	
	@Autowired
	private AlumnosDAO dao;

	@Override
	public Flux<Alumno> consultarTodos() {
		return dao.findAll();
	}

	@Override
	public Mono<Alumno> buscarPorId(String id) {
		return dao.findById(id);
	}
	
	@Override
	public Mono<Alumno> buscarPorNombre(String nombre) {
		return dao.findByNombre(nombre);
	}

	@Override
	public Mono<Alumno> insertar(Alumno alumno) {
		return dao.save(alumno);
	}

	@Override
	public Mono<Void> eliminar(String id) {
		return dao.deleteById(id);
	}

	@Override
	public Mono<Alumno> modificar(Alumno alumno) {
		return dao.save(alumno);
	}

	

}
