package com.softtek.persistence;

import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;

import com.softtek.models.Producto;

//Cualquier Repository de Spring es un componente manejado de Spring y
//no necesita anotacion. Se puede inyectar sin problema
@Repository
public interface ProductosDAO extends R2dbcRepository<Producto, Long>{

}
