package com.softtek.persistence;

import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.r2dbc.repository.R2dbcRepository;
import org.springframework.stereotype.Repository;

import com.softtek.models.Producto;

import reactor.core.publisher.Flux;

//Cualquier Repository de Spring es un componente manejado de Spring y
//no necesita anotacion. Se puede inyectar sin problema
@Repository
public interface ProductosDAO extends R2dbcRepository<Producto, Integer>{
	
	// Ademas de los metodos heredados del Repository podemos seguir utilizando
	// los metodos personalizadoc con las keywords
	

	// Utilizamos los metodos heredados de CrudRepository
	// https://docs.spring.io/spring-data/jpa/docs/current-SNAPSHOT/reference/html/#jpa.repositories
	
	@Query("select * from productos where descripcion LIKE 'P%' ")
	public Flux<Producto> productosP();

}
