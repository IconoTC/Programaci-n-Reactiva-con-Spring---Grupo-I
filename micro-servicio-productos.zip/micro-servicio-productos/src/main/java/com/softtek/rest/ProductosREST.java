package com.softtek.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.softtek.models.Producto;
import com.softtek.service.IProductosService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
public class ProductosREST {
	
	@Autowired
	private IProductosService service;
	
	// http://localhost:8001/listar
	@GetMapping("/listar")
	public Flux<Producto> listar(){
		return service.todos();
	}
	
	// http://localhost:8001/buscar/2
	@GetMapping("/buscar/{id}")
	public Mono<Producto> buscar(@PathVariable Integer id){
		return service.buscar(id);
	}

}
