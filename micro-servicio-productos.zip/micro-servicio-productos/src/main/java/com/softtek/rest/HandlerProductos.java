package com.softtek.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.softtek.models.Producto;
import com.softtek.service.IProductosService;

import reactor.core.publisher.Mono;

@Component
public class HandlerProductos {
	
	@Autowired
	private IProductosService service;
	
	public Mono<ServerResponse> todos(ServerRequest request){
		return ServerResponse.ok()
				.contentType(MediaType.APPLICATION_JSON)
				.body(service.todos(), Producto.class);
	}
	
	public Mono<ServerResponse> buscar(ServerRequest request){
		// Comprobar si existe el producto con ese id o no
		return service.buscar(Integer.parseInt(request.pathVariable("id")))
				.flatMap(prod -> ServerResponse.ok()
						.contentType(MediaType.APPLICATION_JSON)
						.body(Mono.just(prod), Producto.class))
				.switchIfEmpty(ServerResponse.notFound()
				.build());
	}

}
