package com.softtek.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.softtek.models.Producto;
import com.softtek.persistence.ProductosDAO;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class ProductosServiceImpl implements IProductosService{
	
	@Autowired
	private ProductosDAO dao;

	@Override
	public Flux<Producto> todos() {
		return dao.findAll();
	}

	@Override
	public Mono<Producto> buscar(Integer id) {
		return dao.findById(id);
	}

}
