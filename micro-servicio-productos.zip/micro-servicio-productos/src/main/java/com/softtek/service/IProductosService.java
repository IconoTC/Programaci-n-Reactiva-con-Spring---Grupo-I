package com.softtek.service;

import com.softtek.models.Producto;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface IProductosService {
	
	public Flux<Producto> todos();
	
	public Mono<Producto> buscar(Long id);

}
