package com.softtek;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;
import org.springframework.web.reactive.function.server.RequestPredicates;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.softtek.models.Producto;
import com.softtek.persistence.ProductosDAO;
import com.softtek.rest.HandlerProductos;

@SpringBootApplication
@EnableEurekaClient
public class MicroServicioProductosApplication implements CommandLineRunner{
	
	@Autowired
	private ProductosDAO dao;
	
	@Bean
	public RouterFunction<ServerResponse> rutas(HandlerProductos handler){
		return RouterFunctions
				// http://localhost:8001/listar
				.route(RequestPredicates.GET("/listar"), handler::todos)
				// http://localhost:8001/buscar/2
				.andRoute(RequestPredicates.GET("/buscar/{id}"), handler::buscar);
	}

	public static void main(String[] args) {
		SpringApplication.run(MicroServicioProductosApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		

		
		// Carga inicial de datos
		List<Producto> lista = Arrays.asList(
				new Producto("Pantalla", 129.95),
				new Producto("Raton", 32.50),
				new Producto("Teclado", 57.80));
		
		dao.saveAll(lista).subscribe(prod -> System.out.println(prod));
		
		System.out.println("--------");
		dao.productosP().subscribe(prod -> System.out.println(prod));
		
	}

}
