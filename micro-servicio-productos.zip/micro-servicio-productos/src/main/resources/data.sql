CREATE TABLE productos ( 
	id INT AUTO_INCREMENT PRIMARY KEY, 
	descripcion VARCHAR(255), 
	precio DECIMAL(10,2) 
);