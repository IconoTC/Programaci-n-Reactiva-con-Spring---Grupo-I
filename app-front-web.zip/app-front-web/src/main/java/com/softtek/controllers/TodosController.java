package com.softtek.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.softtek.models.Producto;
import com.softtek.services.ITiendaService;

@Controller
@RequestMapping("/")
public class TodosController {
	
	@Autowired
	private ITiendaService service;
	
	@RequestMapping(method = RequestMethod.GET, value = "todos")
	public String execute(Model modelo) {
		
		// Convertir el Flux a una lista
		List<Producto> lista = service.obtenerTodos().toStream().collect(Collectors.toList());
		
		modelo.addAttribute("lista", lista);
		return "mostrarTodos";
		
	}

}
