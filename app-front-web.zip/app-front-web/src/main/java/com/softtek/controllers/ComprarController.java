package com.softtek.controllers;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.softtek.models.Carrito;
import com.softtek.services.ITiendaService;

@Controller
@RequestMapping("/")
public class ComprarController {
	
	@Autowired
	private ITiendaService service;
	
	@PostMapping(value = "comprar")
	public String addPedido(int id, int cantidad, HttpServletRequest request) {
		
		String usuario = null;
		boolean logado = false;
		
		// Recuperar todas las cookies de la peticion,
		// buscar la cookie con el nombreUsuario
		// si existe recuperamos el usuario
		// si no existe, le mandamos al formulario login
		Cookie[] cookies = request.getCookies();
		for (Cookie cookie : cookies) {
			if ("nombreUsuario".equals(cookie.getName())) {
				usuario = cookie.getValue();
				logado = true;
				break;
			}
		}
		
		if (!logado) return "formLogin";
		
		// Si hemos encontrado la cookie agrego el pedido a su carrito
		Carrito carrito = service.agregarPedido(id, cantidad, usuario).block();
		request.setAttribute("carrito", carrito);
		return "mostrarCarrito";
	}
	
	@GetMapping("sacar")
	public String sacarPedido(int id, HttpServletRequest request) {
		String usuario = null;
		
		Cookie[] cookies = request.getCookies();
		for (Cookie cookie : cookies) {
			if ("nombreUsuario".equals(cookie.getName())) {
				usuario = cookie.getValue();
				break;
			}
		}
		
		Carrito carrito = service.eliminarPedido(id, usuario).block();
		request.setAttribute("carrito", carrito);	
		return "mostrarCarrito";
	}
	

}











