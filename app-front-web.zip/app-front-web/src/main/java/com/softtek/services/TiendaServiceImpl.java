package com.softtek.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.softtek.models.Carrito;
import com.softtek.models.Producto;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class TiendaServiceImpl implements ITiendaService{
	
	@Autowired
	private WebClient clientProductos;
	
	@Autowired
	private WebClient clientCarrito;

	@Override
	public Flux<Producto> obtenerTodos() {
		return clientProductos.get()
				.uri("/listar")
				.accept(MediaType.APPLICATION_JSON)
				.retrieve()
				.bodyToFlux(Producto.class);
	}

	@Override
	public Mono<Carrito> crear(String usuario) {
		return clientCarrito.post()
				.uri("/crear/{usuario}", usuario)
				.accept(MediaType.APPLICATION_JSON)
				.retrieve()
				.bodyToMono(Carrito.class);
	}

	@Override
	public Mono<Carrito> consultar(String usuario) {
		return clientCarrito.get()
				.uri("/consultar/{usuario}", usuario)
				.accept(MediaType.APPLICATION_JSON)
				.retrieve()
				.bodyToMono(Carrito.class);
	}

	@Override
	public Mono<Carrito> agregarPedido(int id, int cantidad, String usuario) {
		return clientCarrito.put()
				.uri("/agregar/id/{id}/cantidad/{cantidad}/usuario/{usuario}", id, cantidad,usuario)
				.accept(MediaType.APPLICATION_JSON)
				.retrieve()
				.bodyToMono(Carrito.class);
	}

	@Override
	public Mono<Carrito> eliminarPedido(int id, String usuario) {
		return clientCarrito.delete()
				.uri("/eliminar/id/{id}/usuario/{usuario}", id, usuario)
				.accept(MediaType.APPLICATION_JSON)
				.retrieve()
				.bodyToMono(Carrito.class);
	}

}
