package com.softtek.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.softtek.models.Alumno;
import com.softtek.persistence.AlumnosDAO;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class AlumnosServiceImpl implements IAlumnosService{
	
	@Autowired
	private AlumnosDAO dao;

	@Override
	public Flux<Alumno> consultarTodos() {
		return dao.todos();
	}

	@Override
	public Mono<Alumno> buscarPorId(int id) {
		return dao.buscar(id);
	}

	@Override
	public Mono<Alumno> insertar(Alumno alumno) {
		return dao.insertar(alumno);
	}

	@Override
	public Mono<Void> eliminar(int id) {
		return dao.eliminar(id);
	}

	@Override
	public Mono<Alumno> modificar(Alumno alumno) {
		return dao.modificar(alumno);
	}

}
