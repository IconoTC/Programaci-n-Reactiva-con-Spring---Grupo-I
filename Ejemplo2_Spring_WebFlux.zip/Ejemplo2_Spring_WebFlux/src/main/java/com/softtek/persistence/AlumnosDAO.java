package com.softtek.persistence;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.softtek.models.Alumno;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Repository
public class AlumnosDAO {
	
	
	// Crear una lista de alumnos
	List<Alumno> lista = new LinkedList<>(Arrays.asList(
			new Alumno(1, "Juan", "Lopez", 6.8),
			new Alumno(2, "Maria", "Arias", 4.6),
			new Alumno(3, "Antonio", "Rodriguez", 9.2),
			new Alumno(4, "Laura", "Sanchez", 7.3)));
	

	
	// Retornar todos los alumnos en un Flux
	public Flux<Alumno> todos(){
		return Flux.fromIterable(lista);
	}
	
	// Buscar un alumno por su id, retornar en un Mono
	public Mono<Alumno> buscar(int id){	
		// Solucion 1
		//return Mono.just(lista.stream().filter(alum -> alum.getId() == id).findAny().orElse(new Alumno()));
		
		// Solucion 2
		return todos().filter(alum -> alum.getId() == id).singleOrEmpty();
	}
	
	// Insertar alumno, retornar en un Mono
	public Mono<Alumno> insertar(Alumno alumno){
		lista.add(alumno);
		return Mono.just(alumno);
	}
	
	// Eliminar un alumno, retornar Mono<Void>
	public Mono<Void> eliminar(int id){
		// Opcion 1
		Alumno encontrado = null;
		for (Alumno alumno : lista) {
			if (alumno.getId() == id) {
				encontrado = alumno;
				break;
			}
		}
		lista.remove(encontrado);
		
		// Opcion 2
		lista.removeIf(alumno -> alumno.getId() == id);
		return Mono.empty();
	}
	
	// Modificar un alumno, Mono<Alumno> 
	public Mono<Alumno> modificar(Alumno alumno){
		
		// Solucion 1
//		boolean eliminado = lista.removeIf(alum -> alum.getId() == alumno.getId());
//		System.out.println("Eliminado: " + eliminado);
//		if (eliminado) lista.add(alumno);
//		return Mono.just(alumno);
		
		// Solucion 2
		// int indice = -1;
//		
//		for (int i = 0; i < lista.size(); i++) {
//			Alumno alum = lista.get(i);
//			if (alum.getId() == alumno.getId()) {
//				indice = i;
//				break;
//			}
//		}
//		
//		return Mono.just(lista.set(indice, alumno));
		
		// Solucion 3
//		lista.stream().forEach(alum -> { 
//			if(alum.getId() == alumno.getId()) { 
//				alum.setApellido(alumno.getApellido());
//				alum.setNombre(alumno.getNombre());
//				alum.setNota(alumno.getNota()); 
//			} 
//			}); 
//			return buscar(alumno.getId());
			
		// Solucion 4
			return todos() 
					.index() 	// Flux<Tuple<indice,alumno>>
					.filter(tuple->tuple.getT2().getId() == alumno.getId()) 
					.take(1) 	// Quiero quedarme solo con el primer elemento
					.single()   // Mono<Tuple<indice,alumno>>
					.flatMap(tuple->{ 
						Alumno alumnoMod = tuple.getT2();
						int indice = tuple.getT1().intValue(); // Obtiene el índice del elemento 
						alumnoMod.setApellido(alumno.getApellido()); 
						alumnoMod.setNombre(alumno.getNombre()); 
						alumnoMod.setNota(alumno.getNota()); 
						lista.set(indice, alumnoMod); 
					// Puedes hacer uso del índice aquí 
					return Mono.just(alumnoMod); 
					});
	}
}
