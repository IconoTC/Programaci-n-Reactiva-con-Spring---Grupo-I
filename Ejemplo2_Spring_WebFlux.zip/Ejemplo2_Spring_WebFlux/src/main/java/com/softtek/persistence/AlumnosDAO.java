package com.softtek.persistence;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.softtek.models.Alumno;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Repository
public class AlumnosDAO {
	
	
	// Crear una lista de alumnos
	List<Alumno> lista = new LinkedList<>(Arrays.asList(
			new Alumno(1, "Juan", "Lopez", 6.8),
			new Alumno(2, "Maria", "Arias", 4.6),
			new Alumno(3, "Antonio", "Rodriguez", 9.2),
			new Alumno(4, "Laura", "Sanchez", 7.3)));
	

	
	// Retornar todos los alumnos en un Flux
	public Flux<Alumno> todos(){
		return Flux.fromIterable(lista);
	}
	
	// Buscar un alumno por su id, retornar en un Mono
	public Mono<Alumno> buscar(int id){	
		// Solucion 1
		//return Mono.just(lista.stream().filter(alum -> alum.getId() == id).findAny().orElse(new Alumno()));
		
		// Solucion 2
		return todos().filter(alum -> alum.getId() == id).singleOrEmpty();
	}
	
	// Insertar alumno, retornar en un Mono
	public Mono<Alumno> insertar(Alumno alumno){
		lista.add(alumno);
		return Mono.just(alumno);
	}
	
	// Eliminar un alumno, retornar Mono<Void>
	public Mono<Void> eliminar(int id){
		// Opcion 1
		Alumno encontrado = null;
		for (Alumno alumno : lista) {
			if (alumno.getId() == id) {
				encontrado = alumno;
				break;
			}
		}
		lista.remove(encontrado);
		
		// Opcion 2
		lista.removeIf(alumno -> alumno.getId() == id);
		return Mono.empty();
	}
	
	// Modificar un alumno, Mono<Alumno> 
	public Mono<Alumno> modificar(Alumno alumno){
		
		boolean eliminado = lista.removeIf(alum -> alum.getId() == alumno.getId());
		System.out.println("Eliminado: " + eliminado);
		if (eliminado) lista.add(alumno);
		return Mono.just(alumno);
		
		
		//
//		int indice = lista.indexOf(alumno);
//		return Mono.just(lista.set(indice, alumno));	
	}
}
