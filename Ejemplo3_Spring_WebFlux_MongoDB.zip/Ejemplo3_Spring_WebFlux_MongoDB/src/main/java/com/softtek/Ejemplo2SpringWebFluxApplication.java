package com.softtek;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;

import com.softtek.models.Alumno;
import com.softtek.persistence.AlumnosDAO;

import reactor.core.publisher.Flux;

@SpringBootApplication
public class Ejemplo2SpringWebFluxApplication implements CommandLineRunner{
	
	@Autowired
	private ReactiveMongoTemplate mongoTemplate;
	

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo2SpringWebFluxApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// Borrar los datos anteriores
		mongoTemplate.dropCollection("alumnos").subscribe();
		
		// carga inicial de datos
		// Crear un flujo de alumnos y persistirlos
		
		// Crear una lista de alumnos
		List<Alumno> lista = new LinkedList<>(Arrays.asList(
				new Alumno("Juan", "Lopez", 6.8),
				new Alumno("Maria", "Arias", 4.6),
				new Alumno("Antonio", "Rodriguez", 9.2),
				new Alumno("Laura", "Sanchez", 7.3)));
		
		Flux.fromIterable(lista)
			.flatMap(alum -> mongoTemplate.save(alum))
			.doOnComplete(() -> System.out.println("--- FIN ---"))
			.subscribe(alum -> System.out.println(alum));
					
	}

}
