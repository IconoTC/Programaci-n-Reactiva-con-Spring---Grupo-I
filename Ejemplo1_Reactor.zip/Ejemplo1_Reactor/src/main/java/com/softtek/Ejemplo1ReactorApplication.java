package com.softtek;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.softtek.models.Producto;
import com.softtek.models.ProductoTiendas;
import com.softtek.models.Tiendas;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@SpringBootApplication
public class Ejemplo1ReactorApplication implements CommandLineRunner{
	
	List<Producto> lista = Arrays.asList(
			new Producto(1, "Pantalla", 129.95),
			new Producto(2, "Raton", 32.50),
			new Producto(3, "Teclado", 57.80));
	

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo1ReactorApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		contrapresion_backpressure();		
	}
	
	public void contrapresion_backpressure() {
		// Por defecto, cada vez que nos subscrimos a un Observable
		// le estamos pidiendo que envie toda la informacion de una sola vez
		// La contrapresion consiste en poder decir el subscriptor al publicador
		// cuantos elementos puede procesar para evitar una sobrecarga.
		
//		Flux.range(1, 10)
//			.log()
//			.subscribe(num -> System.out.println(num));
		
		// request(unbounded) ilimitado y recibimos todos los elementos a la vez
		// 1ª forma de solucionarlo
//		Flux.range(1, 10)
//		.log()
//		.subscribe(new Subscriber<Integer>() {
//			
//			private Subscription subscription;
//			private int limite = 2;
//			private int consumido = 0;
//			
//
//			@Override
//			public void onSubscribe(Subscription s) {
//				this.subscription = s;
//				// Queremos recibir los datos de 2 en 2
//				subscription.request(limite); 
//			}
//
//			@Override
//			public void onNext(Integer num) {
//				// Aqui procesamos los elmentos que vamos recibiendo
//				System.out.println("Recibido: " + num);
//				consumido++;
//				if(consumido == limite) {
//					consumido = 0;
//					subscription.request(limite); 
//				}
//			}
//
//			@Override
//			public void onError(Throwable t) {
//				t.printStackTrace();
//			}
//
//			@Override
//			public void onComplete() {
//				System.out.println("--- FIN ---");
//			}
//			
//		});
		
		// 2ª forma de solucionarlo
		Flux.range(1, 10)
			.log()
			.limitRate(2)  // Queremos recibir los datos de 2 en 2
			.doOnComplete(() -> System.out.println("--- FIN ---"))
			.subscribe(num -> System.out.println(num));
	}
	
	public void operador_create() {
		// Flujo infinito
//		Flux.create(emitter -> {
//			Timer timer = new Timer();
//			timer.schedule(new TimerTask() {
//				private int contador = 0;
//				
//				@Override
//				public void run() {
//					contador++;
//					emitter.next(contador);
//				}
//			}, 1000, 500);   // Espera 1 segundo y cada medio segundo emite un dato
//		})
//		.doOnNext(dato -> System.out.println(dato))
//		.subscribe();
		
		// Cuando llegue a 20 lo paramos
		Flux.create(emitter -> {
			Timer timer = new Timer();
			timer.schedule(new TimerTask() {
				private int contador = 0;
				
				@Override
				public void run() {
					if (contador == 20) {
						timer.cancel();
						emitter.complete();
					}
					contador++;
					emitter.next(contador);
				}
			}, 1000, 500);   // Espera 1 segundo y cada medio segundo emite un dato
		})
		.doOnNext(dato -> System.out.println(dato))
		.doOnComplete(() -> System.out.println("--- FIN ---"))
		.subscribe();
	}
	
	public void retardos_delay() throws InterruptedException {
		// Flujo de numeros que lo queremos combinar con retraso de 1 segundo
		Flux<Integer> numeros = Flux.range(1, 10);
		Flux<Long> delay = Flux.interval(Duration.ofSeconds(1));
		
		// El metodo termina y no le da tiempo a mostrar los 10 elementos
		// debido al retraso
//		numeros.zipWith(delay, (num, retardo) -> num)
//			.doOnNext(n -> System.out.println(n))
//			.subscribe();
//		
		// 1ª forma de solucionarlo.
		// Parar el hilo 11 segundos
		//Thread.sleep(11_000);
		
		// 2ª forma de solucionarlo
		numeros.zipWith(delay, (num, retardo) -> num)
			.doOnNext(n -> System.out.println(n))
			.blockLast(); // Bloqueo hasta recibir el ultimo dato, No es una buena practica pero se puede usar
		
	}
	
	public void ejercicio1() {
		// crear un flujo con 10 numeros
		// crear un flujo con 10 letras
		// combinar con zipwith de las 2 formas:  a1, b2, c3, ...etc
		
		// Los flujos tienen el mismo numero de elementos
		// Si no fuese asi, combina solo los elementos del flujo menor y el resto los ignora
		Flux<Integer> numeros = Flux.range(1, 10);
		Flux<Character> letras = Flux.just('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j'); 
		
		// Version 1 con zipWith
		Flux<String> combinacion = numeros.zipWith(letras, (num, letra) -> {
			String s1 = num.toString();
			String s2 = letra.toString();
			return s1.concat(s2);
		});
		combinacion.subscribe(item -> System.out.println(item));
		
		// Version 2 con zipWith
		Flux<String> combinacion2 = numeros.zipWith(letras)
			.map(tupla -> {
				String s1 = tupla.getT1().toString();
				String s2 = tupla.getT2().toString();
				return s1 + s2;
			});
		combinacion2.subscribe(item -> System.out.println(item));
		
	}
	
	public void operador_range() {
		Flux<Integer> numeros = Flux.range(10, 5);  // numeros del 10 al 14; (numero inicial, num_elementos)
		numeros.subscribe(num -> System.out.println(num));
	}
	
	public void combinar_flujos_zipWith() {
		// Crear un mono de un producto
		Mono<Producto> productoMono = Mono.fromCallable(() -> new Producto(1, "Pantalla", 129.95));
		
		// Crear un mono de tiendas
		Mono<Tiendas> tiendasProductoMono = Mono.fromCallable(() -> {
			Tiendas tiendas = new Tiendas();
			tiendas.addTienda("PC Components");
			tiendas.addTienda("Amazon");
			tiendas.addTienda("Media Mark");
			return tiendas;
		});
		
		// Combinamos ambos flujos para obtener el producto con sus tiendas de venta
		Mono<ProductoTiendas> productoTiendas = 
				productoMono.zipWith(tiendasProductoMono, (prod, tiendas) -> new ProductoTiendas(prod, tiendas));
						
		productoTiendas.subscribe(resultado -> System.out.println(resultado));
		
		// Otra forma de hacerlo
		Mono<ProductoTiendas> productoTiendas2 = 
				productoMono.zipWith(tiendasProductoMono)  // Mono<Tuple<Producto, Tiendas>>
				.map(tupla -> {
					Producto prod = tupla.getT1();
					Tiendas tiendas = tupla.getT2();
					return new ProductoTiendas(prod, tiendas); // Mono<ProductoTiendas>
				});
				
		productoTiendas2.subscribe(resultado -> System.out.println(resultado));
	}
	
	public void combinar_flujos_flatMap() {
		// Crear un mono de un producto
		Mono<Producto> productoMono = Mono.fromCallable(() -> new Producto(1, "Pantalla", 129.95));
		
		// Crear un mono de tiendas
		Mono<Tiendas> tiendasProductoMono = Mono.fromCallable(() -> {
			Tiendas tiendas = new Tiendas();
			tiendas.addTienda("PC Components");
			tiendas.addTienda("Amazon");
			tiendas.addTienda("Media Mark");
			return tiendas;
		});
		
		// Combinamos ambos flujos para obtener el producto con sus tiendas de venta
		Mono<ProductoTiendas> productoTiendas = 
				productoMono.flatMap(prod -> tiendasProductoMono.map(
						tiendas -> new ProductoTiendas(prod, tiendas)));
		productoTiendas.subscribe(resultado -> System.out.println(resultado));
		
	}
	
	public void convertir_flux_a_mono() {
		Flux.fromIterable(lista)
				.collectList()  // retorna Mono<List<Producto>>
				.subscribe(lista -> System.out.println(lista));
		
		// Si quiero mostrar los productos de uno en uno
		Flux.fromIterable(lista)
			.collectList()  // retorna Mono<List<Producto>>
			.subscribe(lista -> {
				lista.forEach( p -> System.out.println(p));
			});
	}
	
	public void operacion_flatMap() {
		// El operador map modifica un elemento y lo devuelve al stream pero no es reactivo
		// flatMap modifica el elemento y lo devuelve como reactivo (flux o mono)
		
		// Crear un flujo a partir de una lista de productos
		Flux.fromIterable(lista)
				.flatMap(prod -> {
					if (prod.getDescripcion().equals("Raton")) {
						return Mono.just(prod);
					} else {
						return Mono.empty();
					}
				})
//				.map(prod -> {
//					prod.setDescripcion(prod.getDescripcion().toUpperCase());
//					return prod;
//				})
				.subscribe(prod -> System.out.println(prod));
		
	}
	
	public void operaciones_map_filter() {
		// Modificamos elementos del flujo
		// El operador map me retorna el nuevo elemento a otro flujo
		// Los datos iniciales estan intactos (Observables inmutables)
		Flux<String> datos = Flux.just("uno", "dos", "tres", "cuatro")
				.map(dato -> {
					dato.toUpperCase();
					return dato;
					})
				.doOnNext(System.out::println);
		datos.subscribe();
		
		
		Flux<String> datos2 = Flux.just("uno", "dos", "tres", "cuatro")
				.map(dato -> {
					return dato.toUpperCase();
					})
				.doOnNext(System.out::println);
		datos2.subscribe();
		
		// Crear un flujo a partir de una lista de productos
		List<Producto> lista = new ArrayList<>();
		lista.add(new Producto(1, "Pantalla", 129.95));
		lista.add(new Producto(2, "Raton", 32.50));
		lista.add(new Producto(3, "Teclado", 57.80));
		
		// Los arrays no son iterables
		Flux<Producto> productos = Flux.fromIterable(lista);
		
		// Demostramos que los flujos son inmutables
		productos
			.map(prod -> {
				prod.setDescripcion(prod.getDescripcion().toUpperCase());
				return prod;
				});
			
		// Me estoy subscribiendo al flujo inicial por eso veo las descripciones en minusculas
		productos.subscribe(prod -> System.out.println(prod));
		
		// Vamos a subscribirnos al flujo que es el resultado tras las modificaciones
		productos
			// El operador filter me permite filtrar elementos basandonos en una condicion
			.filter(producto -> producto.getPrecio() > 50)
			.map(prod -> {
				prod.setDescripcion(prod.getDescripcion().toUpperCase());
				return prod;
				})
			.subscribe(p -> System.out.println(p));
	}
	
	public void complete() {
		// Se trata de mostrar un mensaje al final de procesar todo el flujo
		Flux<String> datos = Flux.just("uno", "dos", "tres", "cuatro");

		// Si quiero meter un Runnable necesita 2 consumer:
		// El primero muestra el dato por consola
		// El segundo es null
		datos.subscribe(dato -> System.out.println(dato),null, new Runnable() {
			
			// El metodo run() se ejecuta al terminar el flujo
			@Override
			public void run() {
				System.out.println("----- FIN -----");
				
			}
		});
		
		// Otra forma de hacer lo mismo
		Flux<String> datos2 = Flux.just("uno", "dos", "tres", "cuatro")
				.doOnNext(System.out::println)
				.doOnComplete(new Runnable() {
			
					// El metodo run() se ejecuta al terminar el flujo
					@Override
					public void run() {
						System.out.println("----- FIN -----");
						
					}
				});
		datos2.subscribe();
	}
	
	public void crearFlujos() {
		// Crear un flujo de datos y mostrarlos por consola
//		Flux<String> datos = Flux.just("uno", "dos", "tres", "cuatro")
//				.doOnNext(System.out::println);
//		
		// Manejar excepciones dentro del flujo
		Flux<String> datos = Flux.just("uno", "dos", "" ,"tres", "cuatro")
				.doOnNext(dato -> {
					if (dato.isEmpty()){
						throw new RuntimeException("Dato vacio");
					} 
					System.out.println(dato);
				});
		
		
		// Hasta que no se subscribe no hace nada
		datos.subscribe();
	}

}
