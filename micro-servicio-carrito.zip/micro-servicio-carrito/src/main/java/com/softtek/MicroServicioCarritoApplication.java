package com.softtek;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.server.RequestPredicates;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.softtek.rest.HandlerCarrito;

@SpringBootApplication
@EnableEurekaClient
public class MicroServicioCarritoApplication implements CommandLineRunner{
	
	@Autowired
	private ReactiveMongoTemplate template;
	
//	@Bean
//	public WebClient webClient() {
//		return WebClient.create("http://localhost:8002");
//	}
	
	@Bean
	@LoadBalanced
	public WebClient.Builder webClient() {
		return WebClient.builder().baseUrl("http://servicio-pedidos");
	}
	
	@Bean
	public RouterFunction<ServerResponse> rutas(HandlerCarrito handler){
		return RouterFunctions
				// http://localhost:8003/crear/Pepito
				.route(RequestPredicates.POST("/crear/{usuario}"), handler::crear)
				// http://localhost:8003/cconsultar/Pepito
				.andRoute(RequestPredicates.GET("/consultar/{usuario}"), handler::consultar)
				// http://localhost:8003/agregar/id/1/cantidad/5/usuario/Pepito
				.andRoute(RequestPredicates.PUT("/agregar/id/{id}/cantidad/{cantidad}/usuario/{usuario}"), handler::agregarPedido)
				// http://localhost:8003/eliminar/id/1/usuario/Pepito
				.andRoute(RequestPredicates.DELETE("/eliminar/id/{id}/usuario/{usuario}"), handler::eliminarPedido);
	}

	
	public static void main(String[] args) {
		SpringApplication.run(MicroServicioCarritoApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// Eliminar datos anteriores
		template.dropCollection("carritos").subscribe();
	}

}
