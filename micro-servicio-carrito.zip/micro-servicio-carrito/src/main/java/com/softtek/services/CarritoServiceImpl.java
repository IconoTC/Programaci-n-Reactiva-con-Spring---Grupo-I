package com.softtek.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.softtek.models.Carrito;
import com.softtek.models.Pedido;
import com.softtek.persistence.CarritosDAO;

import reactor.core.publisher.Mono;

@Service
public class CarritoServiceImpl implements ICarritoService{
	
	@Autowired
	private CarritosDAO dao;
	
//	@Autowired
//	private WebClient webClient;
	
	@Autowired
	private WebClient.Builder webClient;

	@Override
	public Mono<Carrito> crear(String usuario) {
		Carrito carrito = new Carrito();
		carrito.setUsuario(usuario);
		return dao.save(carrito);
	}

	@Override
	public Mono<Carrito> consultar(String usuario) {
		return dao.findByUsuario(usuario);
	}

	@Override
	public Mono<Carrito> agregarPedido(int id, int cantidad, String usuario) {
		
		Mono<Pedido> monoPedido = webClient.build()
				.get().uri("/crear/id/{id}/cantidad/{cantidad}",id, cantidad)
				.accept(MediaType.APPLICATION_JSON)
				.retrieve()
				.bodyToMono(Pedido.class);
		
		Mono<Carrito> monoCarrito = consultar(usuario);
				
		// Otra forma de hacerlo

		return monoPedido.zipWith(monoCarrito)  // Mono<Tuple<Pedido, Carrito>>
				.map(tupla -> {
					Pedido p = tupla.getT1();
					Carrito c = tupla.getT2();
					c.getContenido().add(p);
					c.setImporte(c.getImporte() + p.getProducto().getPrecio() * p.getCantidad());
					return c; // Mono<Carrito>
				})
				.flatMap(c -> dao.save(c));
	
	}

	@Override
	public Mono<Carrito> eliminarPedido(int id, String usuario) {
		return dao.findByUsuario(usuario)
			.map(c -> {
				Carrito carro = c.getContenido().stream()
					.filter(ped -> ped.getProducto().getID() == id)
					.map(p -> {
						double precio = p.getProducto().getPrecio();
						int cantidad = p.getCantidad();
						c.setImporte(c.getImporte() - (cantidad * precio));
						return c;
					})
					.findFirst().get();
				carro.getContenido().removeIf(pedido -> pedido.getProducto().getID() == id);
				return c;
			})
			.flatMap(c -> dao.save(c));
		
	}

}
