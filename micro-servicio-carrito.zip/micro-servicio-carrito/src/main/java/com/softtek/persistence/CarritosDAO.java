package com.softtek.persistence;

import org.springframework.data.mongodb.repository.ReactiveMongoRepository;

import com.softtek.models.Carrito;

import reactor.core.publisher.Mono;

// Cualquier Repository de Spring es un componente manejado de Spring y
// no necesita anotacion. Se puede inyectar sin problema
public interface CarritosDAO extends ReactiveMongoRepository<Carrito, String>{
	
	// Ademas de los metodos heredados podemos crear metodos personalizados
	// https://docs.spring.io/spring-data/mongodb/reference/repositories/query-keywords-reference.html
	
	public Mono<Carrito> findByUsuario(String usuario);
	
}	
	
	

