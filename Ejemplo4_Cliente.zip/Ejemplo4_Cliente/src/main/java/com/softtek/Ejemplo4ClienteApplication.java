package com.softtek;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.reactive.function.client.WebClient;

@SpringBootApplication
public class Ejemplo4ClienteApplication {
	
	// En Spring para comunicarnos entre microservicios tenemos 2 alternativas:
	//    - RestTemplate , pertenece a Spring MVC
	//    - Feign  , pertenece a Spring Cloud
	// Ninguna de las 2 son Reactivas
	
	// Necesitamos un cliente Reactivo
	@Bean
	public WebClient webClient() {
		return WebClient.create("http://localhost:8081/api");
	}

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo4ClienteApplication.class, args);
	}

}
