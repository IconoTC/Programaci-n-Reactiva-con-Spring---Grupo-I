package com.softtek.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;

import com.softtek.models.Alumno;

import reactor.core.publisher.Flux;

@RestController
public class ClienteREST {
	
	@Autowired
	private WebClient webClient;
	
	// http://localhost:8082/todos
	@GetMapping("/todos")
	public Flux<Alumno> todos(){
		return webClient.get().uri("/alumnos")
				.retrieve()  // Extraemos la respuesta
				.bodyToFlux(Alumno.class);
	}

}
