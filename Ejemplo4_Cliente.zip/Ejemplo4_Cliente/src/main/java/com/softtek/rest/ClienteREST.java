package com.softtek.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import com.softtek.models.Alumno;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
public class ClienteREST {

	@Autowired
	private WebClient webClient;

	// http://localhost:8082/todos
	@GetMapping("/todos")
	public Flux<Alumno> todos() {
		return webClient.get().uri("/alumnos").retrieve() // Extraemos la respuesta
				.bodyToFlux(Alumno.class);
	}

	// http://localhost:8082/buscarid/........
	@GetMapping("/buscarid/{id}")
	public Mono<Alumno> buscarPorID(@PathVariable String id) {
		return webClient.get().uri("/alumnos/{id}", id)
				.retrieve()
				.bodyToMono(Alumno.class);
	}

	// http://localhost:8082/buscarnombre/........
	@GetMapping("/buscarnombre/{nombre}")
	public Mono<Alumno> buscarPorNombre(@PathVariable String nombre) {
		return webClient.get().uri("/alumnos/nombre/{nombre}", nombre)
				.retrieve()
				.bodyToMono(Alumno.class);
	}
	
	@PostMapping("/alta")
	public Mono<Alumno> insertar(@RequestBody Alumno alumno){
		return webClient.post().uri("/alumnos")
				.body(BodyInserters.fromValue(alumno))
				.retrieve()
				.bodyToMono(Alumno.class);
	}

}










