package com.softtek.services;

import com.softtek.models.Alumno;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface IAlumnosService {
	
	public Flux<Alumno> consultarTodos();
	
	public Mono<Alumno> buscarPorId(Integer id);
	
	public Mono<Alumno> buscarPorNombre(String nombre);
	
	public Mono<Alumno> insertar(Alumno alumno);
	
	public Mono<Void> eliminar(Integer id);
	
	public Mono<Alumno> modificar(Alumno alumno);

}
