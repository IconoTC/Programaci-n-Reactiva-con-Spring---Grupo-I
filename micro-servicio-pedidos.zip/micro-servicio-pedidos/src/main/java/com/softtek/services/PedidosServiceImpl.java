package com.softtek.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.reactive.ReactorLoadBalancerExchangeFilterFunction;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.softtek.models.Pedido;
import com.softtek.models.Producto;

import reactor.core.publisher.Mono;

@Service
public class PedidosServiceImpl implements IPedidosService{
	

	@Autowired
	private WebClient.Builder webClient;
	
//	@Autowired
//	private WebClient webClient;

	@Override
	public Mono<Pedido> crearPedido(int id, int cantidad) {
		// Tomando el id del producto, queremos lanzar una peticion
		// al micro-servicio-productos para obtener el producto
		// y así poder crear el pedido que retornamos
		
		Mono<Producto> monoProducto = webClient.build()
				.get().uri("/buscar/{id}",id)
				.accept(MediaType.APPLICATION_JSON)
				.retrieve()
				.bodyToMono(Producto.class);		
		
		Mono<Integer> monoCantidad = Mono.just(cantidad);
		
		Mono<Pedido> monoPedido = monoProducto.flatMap(prod -> monoCantidad.map(c -> new Pedido(prod, c)));

		return monoPedido;
				
	}

}
