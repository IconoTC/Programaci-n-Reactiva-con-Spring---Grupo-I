package com.softtek.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.softtek.models.Pedido;
import com.softtek.services.IPedidosService;

import reactor.core.publisher.Mono;

@Component
public class HandlerPedidos {
	
	@Autowired
	private IPedidosService service;
	
	public Mono<ServerResponse> crearPedido(ServerRequest request){
		
		int id = Integer.parseInt(request.pathVariable("id"));
		int cantidad = Integer.parseInt(request.pathVariable("cantidad"));
		
		// Primera opcion
		return ServerResponse.ok()
				.contentType(MediaType.APPLICATION_JSON)
				.body(service.crearPedido(id, cantidad), Pedido.class);
		
		
		// Segunda opcion
//		return service.crearPedido(id, cantidad)
//				.flatMap(pedido -> ServerResponse.ok()
//						.contentType(MediaType.APPLICATION_JSON)
//						.body(Mono.just(pedido), Pedido.class))
//				.switchIfEmpty(ServerResponse.notFound()
//				.build());
	}

}
